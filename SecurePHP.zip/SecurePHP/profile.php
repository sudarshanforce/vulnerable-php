<?php
    include 'connection.php';
    if(isset($_SESSION['isLoggedIn'])) {
        if(isset($_POST['submit']) && isset($_SESSION['isLoggedIn']))
        {
            $id = $_SESSION['id'];
            $username = htmlspecialchars($_POST['username']);
            $email = htmlspecialchars($_POST['email']);
            $u_id = $_SESSION['id'];
            $stmt1 = $conn->prepare("SELECT id, username, email FROM users WHERE id=? LIMIT 1");
            $stmt1->bind_param('s', $u_id);
            $stmt1->execute();
            $stmt1->bind_result($id4, $username4, $email4);
            $stmt1->store_result();
            if($stmt1->num_rows == 1) {
                if($stmt1->fetch()) {
                    if($id4 == $id) {
                        
                        $stmt4 = $conn->prepare("UPDATE users SET username = ? WHERE id = ?");
                        $stmt4->bind_param("si", $username, $id);
                        $stmt4->execute();
                        $stmt4->close();
                        $stmt4 = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
                        $stmt4->bind_param("si", $email, $id);
                        $stmt4->execute();
                        $stmt4->close();
                    }
                }
            }
            header("Location: profile.php");
        }  
        if(isset($_POST['logout']) && isset($_SESSION['isLoggedIn']))
        {
            unset($_SESSION['id']);
            unset($_SESSION['isLoggedIn']);
            session_destroy();
            header("Location: index.php");
        }
    } /*else {
        session_destroy();
        header("Location: index.php");
    } */           
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>Secure Coding</title>
  </head>
  <?php 
    $id=$_SESSION['id'];
   
    $stmt = $conn->prepare("SELECT id, username, email FROM users WHERE id=? LIMIT 1");
    $stmt->bind_param('s', $id);
    $stmt->execute();
    $stmt->bind_result($id, $username, $email);
    $stmt->store_result();
    //print_r($stmt);
    if($stmt->num_rows == 1) {
        if($stmt->fetch()) {
            $uname = $username;
            $email = $email;
        }
    }
  ?>
<body>
<div class="container py-2">
    <div class="jumbotron">
        <h1>User Profile</h1>
         <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <div class="form-group">
                <label>Username:</label>
                <input type="text" class="form-control" name="username" pattern="[a-zA-Z]+" value="<?php echo $uname; ?>" required />
            <div>
            <div class="form-group">
                <label>Email:</label>
                <input type="email" class="form-control" name="email" value="<?php echo $email; ?>"  required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" />
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-success" name="submit">Update</button>
                <button name="logout" class="btn btn-danger">Log out</button>
            </div>
        </form>
    <div>
<div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
