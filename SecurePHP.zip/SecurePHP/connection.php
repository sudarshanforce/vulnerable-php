<?php
    session_start();
    $host = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "secure_coding";
    
    
    $conn = new mysqli($host, $dbuser, $dbpass, $dbname);

    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

?>