<?php 
  
  include "connection.php";

  if(isset($_POST['username']) && isset($_POST['password'])) {
      $uname = htmlspecialchars($_POST['username']);
      $password = $_POST['password'];
      $pass = '';
      


        $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username=? LIMIT 1");
        $stmt->bind_param('s', $uname);
        $stmt->execute();
        $stmt->bind_result($id, $username, $pass);
        $stmt->store_result();
        //print_r($stmt);
        if($stmt->num_rows == 1) {
          if($stmt->fetch()) {//fetching the contents of the row
            if ($pass == $password) {
              $_SESSION['isLoggedIn'] = true;
              $_SESSION["id"]=$id;
              header("Location: profile.php");
              //print_r($id);
            }
          }
        }     

    } else if(isset($_SESSION["isLoggedIn"])) {
        header("Location: profile.php");
    } 

?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>Secure Coding</title>
  </head>
  <body>
  <div class="container py-2">
    <div class="jumbotron">
      <h1>Login</h1>
       <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <div class="form-group">
          <label>Username</label>
          <input type="text" class="form-control" name="username" placeholder="Enter Username" pattern="[a-zA-Z]+" required>
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" class="form-control" name="password" placeholder="Enter Password" required>
        </div>
        <div class="form-group">
          <button class="btn btn-success" type="submit">Login</button>
        </div>
      </form>
    </div>
  </div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  </body>
</html>